/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.myCustomTheme = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
;
